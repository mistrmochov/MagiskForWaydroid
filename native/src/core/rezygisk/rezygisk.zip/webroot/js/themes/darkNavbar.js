export function setDarkNav() {
  document.getElementById('ni_home').classList.remove('light')
  document.getElementById('ni_modules').classList.remove('light')
  document.getElementById('ni_actions').classList.remove('light')
  document.getElementById('ni_settings').classList.remove('light')
}